﻿======================================================================
                   FastCopy  ver5.7.15                   2024/08/12
                                                 SHIROUZU Hiroaki
                                                 FastCopy Lab, LLC.
======================================================================

  FastCopy is the Fastest Copy/Delete Software on Windows.

  It can copy/delete unicode and over MAX_PATH(260byte) pathname files.

  It always run by multi-threading.

  It don't use MFC, it is compact and don't requre mfcxx.dll.

  FastCopy is GPLv3 license, you can modify and use under GPLv3


FastCopy End User License Agreement (EULA):

  1. (Usage License) This software requires a Pro version license
     for use in non-domestic environments, such as workplaces.
     It is only available for free use by individuals (non-profit)
     within the household.

  2. (Disclaimer) FastCopy Lab, LLC. provides this software `as is'
     and does not assume any responsibility or liability for any
     defects.

  3. (Prohibition of Reverse Engineering) Reverse engineering by
     any means is prohibited.

  4. (Prohibition of Transfer) Lending, transferring,
     or sublicensing the Pro version license to a third party
     is prohibited.

  Copyright 2004-2024 SHIROUZU Hiroaki All rights reserved.
  Copyright 2018-2024 FastCopy Lab, LLC. All rights reserved.

  xxHash library Copyright (C) 2012-2023 Mr.Yann Collet, All rights reserved.
    more details: doc/xxhash-LICENSE.txt

  OpenSSL library Copyright (C) 1998-2023 The OpenSSL Project,
    All rights reserved. more details: doc/apache-license-2.0.txt


Usage：
  Please see fastcopy_eng.htm

