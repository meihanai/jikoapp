# 自用存档

启动
```shell
aria2c --conf-path=E:/Scoop/apps/aria2/current/aria2.conf -D
```

## 配置文件

```
https://github.com/P3TERX/aria2.conf/blob/master/aria2.conf
```

## aria

```
https://github.com/myfreeer/aria2-build-msys2/releases
```
## 不要忘记修改

下载目录

```
dir=D:/tuki/Downloads/Aria2
```


all-proxy=http://127.0.0.1:2080

input-file=E:/Scoop/apps/aria2/current/.aria2/aria2.session

save-session=E:/Scoop/apps/aria2/current/.aria2/aria2.session

netrc-path=E:/Scoop/apps/aria2/current/.aria2/.netrc

dht-file-path=E:/Scoop/apps/aria2/current/.cache/aria2/dht.dat

dht-file-path6=E:/Scoop/apps/aria2/current/.cache/aria2/dht6.dat

log=E:/Scoop/apps/aria2/current/logs/aria2.log